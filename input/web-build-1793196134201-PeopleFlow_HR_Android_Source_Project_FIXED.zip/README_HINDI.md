# PeopleFlow HR Android project — Hindi guide

## Important truth
Yeh **Android Studio source project** hai, APK file nahi. Is environment mein Android SDK/Gradle build tools available nahi hain, isliye signed APK build aur install test nahi kiya gaya. App tabhi HRMS kholegi jab PeopleFlow HR ki actual HTTPS website deploy ho chuki ho.

## APK banane ka tareeqa
1. Laptop par Android Studio install karein: https://developer.android.com/studio
2. Android Studio kholen → **Open** → is extracted folder ko select karein.
3. Gradle sync complete hone dein; agar Android SDK 35 missing ho, SDK Manager se install karein.
4. Test build: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK path Android Studio ke Build output mein dikh jayega, aam taur par `app/build/outputs/apk/debug/app-debug.apk`.
6. Phone mein APK copy karke install karein. Android settings mein is file manager ke liye “Install unknown apps” allow karna pad sakta hai.
7. App kholne par apni deployed website ka `https://...` URL enter karein.

## Website URL abhi kyun nahi hai?
The existing Flask project has not passed runtime/security acceptance tests and has not been deployed. Do not enter a made-up URL. First deploy the test web app; use only dummy data until security review is complete.

## Security
- App HTTPS URL only accepts karti hai.
- App login, payroll ya employee database locally bundle nahi karti; website backend chahiye.
- Production-ready HRMS nahi hai; source wrapper ko commercial app na samjhein.
- Kisi ko password/OTP share na karein.
