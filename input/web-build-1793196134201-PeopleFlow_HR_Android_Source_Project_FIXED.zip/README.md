# PeopleFlow HR Android wrapper source

This is an Android Gradle source project for a basic WebView wrapper app branded PeopleFlow HR by Rudransh Enterprises.

Important: This is NOT the complete HRMS product and does not include a deployed backend or live HR website. It needs a configured HTTPS web URL to display a working web application.

Build target: Android APK (debug)
Gradle Android plugin: 8.7.3
Kotlin: 2.0.21
Compile SDK: 35
