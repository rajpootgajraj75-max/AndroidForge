package com.rudranshenterprises.peopleflowhr

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("peopleflow_settings", MODE_PRIVATE) }
    private var webView: WebView? = null
    private val blue = Color.rgb(25, 48, 88)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = prefs.getString("base_url", "") ?: ""
        if (saved.isBlank()) showSetup() else loadSite(saved)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showSetup(message: String = "Online PeopleFlow HR address abhi set nahi hai.") {
        webView?.destroy()
        webView = null
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        val title = TextView(this).apply {
            text = "PeopleFlow HR"
            textSize = 28f
            setTextColor(blue)
            gravity = Gravity.CENTER
        }
        val brand = TextView(this).apply {
            text = "Rudransh Enterprises"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(24))
        }
        val info = TextView(this).apply {
            text = "$message\n\nYeh Android app aapki PeopleFlow HR website ko kholta hai. Live website deploy hone ke baad uska HTTPS URL yahan daalein. Abhi koi live URL configured nahi hai."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, dp(18))
        }
        val input = EditText(this).apply {
            hint = "https://your-peopleflow-url.onrender.com"
            textSize = 15f
            setSingleLine(true)
            setText(prefs.getString("base_url", "") ?: "")
        }
        val save = Button(this).apply {
            text = "Open PeopleFlow HR"
            setOnClickListener {
                val url = input.text.toString().trim()
                if (!url.startsWith("https://")) {
                    Toast.makeText(this@MainActivity, "Security ke liye HTTPS URL zaroori hai.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val uri = Uri.parse(url)
                if (uri.host.isNullOrBlank()) {
                    Toast.makeText(this@MainActivity, "Valid website URL daalein.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit().putString("base_url", url.trimEnd('/')).apply()
                loadSite(url.trimEnd('/'))
            }
        }
        val openBrowser = Button(this).apply {
            text = "URL browser mein kholen"
            setOnClickListener {
                val url = input.text.toString().trim()
                if (url.startsWith("https://")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } else Toast.makeText(this@MainActivity, "Pehle valid HTTPS URL daalein.", Toast.LENGTH_LONG).show()
            }
        }
        layout.addView(title, matchWrap())
        layout.addView(brand, matchWrap())
        layout.addView(info, matchWrap())
        layout.addView(input, matchWrap())
        layout.addView(save, matchWrap())
        layout.addView(openBrowser, matchWrap())
        setContentView(layout)
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        }

    private fun loadSite(url: String) {
        if (!url.startsWith("https://")) {
            showSetup("Sirf secure HTTPS website allowed hai.")
            return
        }
        val view = WebView(this)
        webView = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.allowFileAccess = false
        view.settings.allowContentAccess = false
        view.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        view.webChromeClient = WebChromeClient()
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                val target = request.url
                if (target.scheme == "https" && target.host == Uri.parse(url).host) return false
                startActivity(Intent(Intent.ACTION_VIEW, target))
                return true
            }
            override fun onReceivedError(v: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) showSetup("Website load nahi hui. URL ya deployment check karein.")
            }
        }
        setContentView(view)
        view.loadUrl(url)
    }

    override fun onBackPressed() {
        val v = webView
        if (v != null && v.canGoBack()) v.goBack() else showSetup()
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
