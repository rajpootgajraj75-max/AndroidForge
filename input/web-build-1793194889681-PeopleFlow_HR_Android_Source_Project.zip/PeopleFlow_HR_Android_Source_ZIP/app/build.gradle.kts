plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.rudranshenterprises.peopleflowhr"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.rudranshenterprises.peopleflowhr"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-test"
    }
}
